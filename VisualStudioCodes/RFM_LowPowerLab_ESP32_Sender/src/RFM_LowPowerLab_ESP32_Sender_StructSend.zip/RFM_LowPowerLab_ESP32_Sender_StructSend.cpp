// **********************************************************************************
// Struct Send RFM69 Example
// **********************************************************************************
// Copyright Felix Rusu 2018, http://www.LowPowerLab.com/contact
// **********************************************************************************
// License
// **********************************************************************************
// This program is free software; you can redistribute it 
// and/or modify it under the terms of the GNU General    
// Public License as published by the Free Software       
// Foundation; either version 3 of the License, or        
// (at your option) any later version.                    
//                                                        
// This program is distributed in the hope that it will   
// be useful, but WITHOUT ANY WARRANTY; without even the  
// implied warranty of MERCHANTABILITY or FITNESS FOR A   
// PARTICULAR PURPOSE. See the GNU General Public        
// License for more details.                              
//                                                        
// Licence can be viewed at                               
// http://www.gnu.org/licenses/gpl-3.0.txt
//
// Please maintain this license information along with authorship
// and copyright notices in any redistribution of this code
// **********************************************************************************
#include <RFM69.h>         //get it here: https://www.github.com/lowpowerlab/rfm69
#include <RFM69_ATC.h>     //get it here: https://www.github.com/lowpowerlab/rfm69
//#include <SPIFlash.h>      //get it here: https://www.github.com/lowpowerlab/spiflash
#include <SPI.h>           //included with Arduino IDE install (www.arduino.cc)
#include <RFM69registers.h> // Include- block, needed for recognition of REG_BITRATEMSB / REG_BITRATELSB


#include <Arduino.h>
#include <U8g2lib.h>
#include <U8x8lib.h>
#ifdef U8X8_HAVE_HW_I2C
#include <Wire.h>
#endif

//U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE);  
U8X8_SH1106_128X64_NONAME_HW_I2C u8x8(/* reset=*/ U8X8_PIN_NONE);

//*********************************************************************************************
//************ IMPORTANT SETTINGS - YOU MUST CHANGE/CONFIGURE TO FIT YOUR HARDWARE *************
//*********************************************************************************************
#define NODEID      99
#define NETWORKID   100
#define GATEWAYID   1
//Match frequency to the hardware version of the radio on your Moteino (uncomment one):
#define FREQUENCY       RF69_433MHZ
//#define FREQUENCY     RF69_868MHZ
//#define FREQUENCY     RF69_915MHZ
#define ENCRYPTKEY    "sampleEncryptKey" //has to be same 16 characters/bytes on all nodes, not more not less!
#define IS_RFM69HW_HCW  //uncomment only for RFM69HW/HCW! Leave out if you have RFM69W/CW!
//*********************************************************************************************
//Auto Transmission Control - dials down transmit power to save battery
//Usually you do not need to always transmit at max output power
//By reducing TX power even a little you save a significant amount of battery power
//This setting enables this gateway to work with remote nodes that have ATC enabled to
//dial their power down to only the required level
//#define ENABLE_ATC    //comment out this line to disable AUTO TRANSMISSION CONTROL
//*********************************************************************************************
#define SERIAL_BAUD 115200
#define RESET_PIN 4

#ifdef ENABLE_ATC
  RFM69_ATC radio;
#else
  //RFM69 radio;
  RFM69 radio;// = RFM69(9, 4, true, 4);
#endif

//SPIFlash flash(SS_FLASHMEM, 0xEF30); //EF40 for 16mbit windbond chip
//Global variables:
int TRANSMITPERIOD = 300; //transmit a packet to gateway so often (in ms)
byte sendSize=0;
boolean requestACK = false;

typedef struct {
  int           nodeId; //store this nodeId
  unsigned long uptime; //uptime in ms
  float         temp;   //temperature maybe?
} Payload;
Payload theData;
bool LEDState;

int previousMillis_StandBy;
unsigned long currentMillis = millis();
unsigned long previousMillis_LoadingIcon = 0;
int IconState = 0;
int CurrentRSSI = 0;
uint32_t packetCount = 0;
char IncomingMsg_char[230];
int IncomingMsg_int[230];
int IncomingMSG_Lenght;


// functions:
void ResetRadio();
void AliveAnimation2();
void DisplayUpdater();
void Blink(byte PIN, int DELAY_MS);

void setup() {
  pinMode(RESET_PIN,OUTPUT); //init RMF69 reset pin
  pinMode(LED_BUILTIN,OUTPUT);

  Serial.begin(SERIAL_BAUD); 
  delay(10);
  ResetRadio();
  Serial.printf("ResetRadio after: \n");
  radio.initialize(FREQUENCY,NODEID,NETWORKID);
/*
radio.writeReg(REG_BITRATEMSB, RF_BITRATEMSB_1200); // setup- function, after radio.initialize(...)
radio.writeReg(REG_BITRATELSB, RF_BITRATELSB_1200);   // setup- function, after radio.initialize(...)

radio.writeReg(REG_FDEVMSB, RF_FDEVMSB_2000);
radio.writeReg(REG_FDEVLSB, RF_FDEVLSB_2000);
*/



  Serial.printf("initialize after: \n");
  #ifdef IS_RFM69HW_HCW
    radio.setHighPower(); //must include this only for RFM69HW/HCW!
  #endif
  radio.encrypt(ENCRYPTKEY);
  char buff[50];
  sprintf(buff, "\nTransmitting at %d Mhz...", FREQUENCY==RF69_433MHZ ? 433 : FREQUENCY==RF69_868MHZ ? 868 : 915);
  Serial.println(buff);
  //radio.setPowerLevel(28);
  /*u8g2.begin();  
  u8g2.enableUTF8Print();
  u8g2.setDisplayRotation(U8G2_R2);*/

  u8x8.begin();


  Serial.print("MOSI: ");
  Serial.println(MOSI);
  Serial.print("MISO: ");
  Serial.println(MISO);
  Serial.print("SCK: ");
  Serial.println(SCK);
  Serial.print("SS: ");
  Serial.println(SS); 
}

long lastPeriod = -1;
void loop() {
  
currentMillis = millis(); 
DisplayUpdater();


  //process any serial input
  if (Serial.available() > 0)
  {
    char input = Serial.read();
    if (input >= 48 && input <= 57) //[0,9]
    {
      TRANSMITPERIOD = 100 * (input-48);
      if (TRANSMITPERIOD == 0) TRANSMITPERIOD = 1000;
      Serial.print("\nChanging delay to ");
      Serial.print(TRANSMITPERIOD);
      Serial.println("ms\n");
    }
    
    if (input == 'r') //d=dump register values
      radio.readAllRegs();
    if (input == 'i') //i=module info
    {
      Serial.println("This is a NODE");
      Serial.print("Module ID: "); Serial.println(NODEID);
      Serial.print("Network ID: "); Serial.println(NETWORKID);
      Serial.print("Gateway ID: "); Serial.println(GATEWAYID);
    }
      
  }

  //check for any received packets
  if (radio.receiveDone())
  {
    Serial.print('[');Serial.print(radio.SENDERID, DEC);Serial.print("] ");
    for (byte i = 0; i < radio.DATALEN; i++)
      Serial.print((char)radio.DATA[i]);
    Serial.print("   [RX_RSSI:");Serial.print(radio.readRSSI());Serial.print("]");

    if (radio.ACKRequested())
    {
      radio.sendACK();
      Serial.print(" - ACK sent");
      delay(10);
    }
    //Blink(LED_BUILTIN,5);
    Serial.println();
  }
  
  int currPeriod = millis()/TRANSMITPERIOD;
  if (currPeriod != lastPeriod)
  {
    //fill in the struct with new values
    theData.nodeId = NODEID;
    theData.uptime = millis();
    theData.temp = 91.23; //it's hot!
    
    Serial.print("Sending struct (");
    Serial.print(sizeof(theData));
    Serial.print(" bytes) ... ");
    if (radio.sendWithRetry(GATEWAYID, (const void*)(&theData), sizeof(theData)))
      Serial.print(" ok!");
    else Serial.print(" nothing...");
    Serial.println();
    Blink(LED_BUILTIN,3);
    lastPeriod=currPeriod;
    //LEDState = !LEDState;
    //digitalWrite(LED_BUILTIN,LEDState);
  }
}



void ResetRadio()
{
  digitalWrite(RESET_PIN, HIGH);
  delay(10);
  digitalWrite(RESET_PIN, LOW);
  Serial.println("Radio reseted!");
}

void Blink(byte PIN, int DELAY_MS)
{
  pinMode(PIN, OUTPUT);
  digitalWrite(PIN,HIGH);
  delay(DELAY_MS);
  digitalWrite(PIN,LOW);
}




/*
void AliveAnimation(){


  if (currentMillis - previousMillis_LoadingIcon >= 80) {
    // save the last time you blinked the LED
    previousMillis_LoadingIcon = currentMillis;
    IconState++;
    if(IconState == 8){
      IconState = 0;
    }
  }

  u8g2.setDrawColor(1);

  switch (IconState){
    case 0:
      u8g2.setDrawColor(1);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_RIGHT );
      u8g2.setDrawColor(0);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_LEFT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_LEFT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_RIGHT );
      break;

    case 1:
      u8g2.setDrawColor(1);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_RIGHT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_LEFT );
      u8g2.setDrawColor(0);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_LEFT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_RIGHT );
      break;
    case 2:
      u8g2.setDrawColor(1);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_RIGHT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_LEFT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_LEFT );
      u8g2.setDrawColor(0);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_RIGHT );
      break;
    case 3:
      u8g2.setDrawColor(1);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_RIGHT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_LEFT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_LEFT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_RIGHT );
      u8g2.setDrawColor(0);
      break;



    case 4:
      u8g2.setDrawColor(0);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_RIGHT );
      u8g2.setDrawColor(1);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_LEFT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_LEFT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_RIGHT );
      break;
    case 5:
      u8g2.setDrawColor(0);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_RIGHT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_LEFT );
      u8g2.setDrawColor(1);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_LEFT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_RIGHT );
      break;
    case 6:
      u8g2.setDrawColor(0);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_RIGHT );
      
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_LEFT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_LEFT );
      u8g2.setDrawColor(1);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_RIGHT );
      break;
    case 7:
      u8g2.setDrawColor(0);
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_RIGHT );
      
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_UPPER_LEFT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_LEFT );
      u8g2.drawCircle(123, 4, 4,U8G2_DRAW_LOWER_RIGHT );
      u8g2.setDrawColor(1);
      break;
        
    }
    
  u8g2.setDrawColor(1);
}
*/
void DisplayUpdater(){

  //u8g2.clearBuffer(); // clear the internal memory
  AliveAnimation2();
u8x8.setFont(u8x8_font_5x8_f );


u8x8.setCursor(0,3); 
u8x8.print("MOSI: ");u8x8.print(MOSI);
u8x8.setCursor(0,4); 
u8x8.print("MISO: ");u8x8.print(MISO);
u8x8.setCursor(0,5); 
u8x8.print("SCK: ");u8x8.print(SCK);
u8x8.setCursor(0,6); 
u8x8.print("SS: ");u8x8.print(SS);


/*
u8g2.setCursor(0,21); 
u8g2.print("MOSI: ");u8g2.print(MOSI);
u8g2.setCursor(0,28); 
u8g2.print("MISO: ");u8g2.print(MISO);
u8g2.setCursor(0,35); 
u8g2.print("SCK: ");u8g2.print(SCK);
u8g2.setCursor(0,42); 
u8g2.print("SS: ");u8g2.print(SS);


u8x8.setCursor(1,1); 
    u8x8.print("SInput:");
    u8x8.print(InputFromSerial);u8x8.print("           ");

*/


  //u8g2.sendBuffer();          // transfer internal memory to the display
}




void AliveAnimation2(){

  if (millis() - previousMillis_LoadingIcon >= 25) {
    // save the last time you blinked the LED
    previousMillis_LoadingIcon = millis();
    IconState++;
    if(IconState == 39){
      IconState = 0;
    }
  

    uint8_t CircleBitMap[312]={
      0,	0,	0,	0,	0,	0,	0,	0,
      0,	0,	0,	0,	1,	0,	0,	0,
      0,	0,	0,	0,	1,	1,	0,	0,
      0,	0,	0,	0,	1,	1,	2,	0,
      0,	0,	0,	0,	1,	1,	2,	4,
      0,	0,	0,	0,	1,	1,	2,	12,
      0,	0,	0,	0,	1,	1,	2,	28,
      0,	0,	0,	0,	1,	1,	2,	60,
      0,	0,	0,	0,	1,	1,	66,	60,
      0,	0,	0,	0,	1,	129,	66,	60,
      0,	0,	0,	0,	129,	129,	66,	60,
      0,	0,	0,	128,	129,	129,	66,	60,
      0,	0,	128,	128,	129,	129,	66,	60,
      0,	64,	128,	128,	129,	129,	66,	60,
      32,	64,	128,	128,	129,	129,	66,	60,
      48,	64,	128,	128,	129,	129,	66,	60,
      60,	64,	128,	128,	129,	129,	66,	60,
      60,	66,	128,	128,	129,	129,	66,	60,
      60,	66,	129,	128,	129,	129,	66,	60,
      60,	66,	129,	129,	129,	129,	66,	60,

      60,	66,	129,	129,	128,	129,	66,	60,
      60,	66,	129,	129,	128,	128,	66,	60,
      60,	66,	129,	129,	128,	128,	64,	60,
      60,	66,	129,	129,	128,	128,	64,	56,
      60,	66,	129,	129,	128,	128,	64,	48,
      60,	66,	129,	129,	128,	128,	64,	32,
      60,	66,	129,	129,	128,	128,	64,	0,
      60,	66,	129,	129,	128,	128,	0,	0,
      60,	66,	129,	129,	128,	0,	0,	0,
      60,	66,	129,	129,	0,	0,	0,	0,
      60,	66,	129,	1,	0,	0,	0,	0,
      60,	66,	1,	1,	0,	0,	0,	0,
      60,	2,	1,	1,	0,	0,	0,	0,
      28,	2,	1,	1,	0,	0,	0,	0,
      12,	2,	1,	1,	0,	0,	0,	0,
      4,	2,	1,	1,	0,	0,	0,	0,
      0,	2,	1,	1,	0,	0,	0,	0,
      0,	0,	1,	1,	0,	0,	0,	0,
      0,	0,	0,	1,	0,	0,	0,	0
      

    };


    uint8_t tiles[8] = {
      CircleBitMap[IconState*8+0],
      CircleBitMap[IconState*8+1],
      CircleBitMap[IconState*8+2],
      CircleBitMap[IconState*8+3],
      CircleBitMap[IconState*8+4],
      CircleBitMap[IconState*8+5],
      CircleBitMap[IconState*8+6],
      CircleBitMap[IconState*8+7]
    };

    //uint8_t tiles2[8] = {60,	66,	129,	129,	129,	129,	66,	60};
    u8x8.drawTile(15, 7, 1, tiles);



  }
}